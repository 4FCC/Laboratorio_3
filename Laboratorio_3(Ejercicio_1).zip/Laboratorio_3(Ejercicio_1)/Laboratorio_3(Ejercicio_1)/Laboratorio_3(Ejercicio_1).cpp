#include <iostream>

int** transpuesta(int** matriz, int n) {
    int** matriz_transpuesta = new int* [n];
    for (int i = 0; i < n; i++) {
        matriz_transpuesta[i] = new int[n];
        for (int j = 0; j < n; j++) {
            matriz_transpuesta[i][j] = matriz[j][i];
        }
    }
    return matriz_transpuesta;
}

int main() {
    int n = 3;
    int** matriz = new int* [n];

    // Inicializar la matriz original.
    for (int i = 0; i < n; i++) {
        matriz[i] = new int[n];
        for (int j = 0; j < n; j++) {
            matriz[i][j] = i * n + j;
        }
    }

    // Imprimir la matriz original.
    std::cout << "Matriz original:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }

    int** matriz_transpuesta = transpuesta(matriz, n);

    // Imprimir la matriz transpuesta.
    std::cout << "Matriz transpuesta:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << matriz_transpuesta[i][j] << " ";
        }
        std::cout << std::endl;
    }

    // Liberar la memoria
    for (int i = 0; i < n; i++) {
        delete[] matriz[i];
        delete[] matriz_transpuesta[i];
    }
    delete[] matriz;
    delete[] matriz_transpuesta;

    return 0;
}
