#include <iostream>

int main() {
    int primerDia, esBisiesto;

    std::cout << "Ingrese el d�a de la semana en que inicia el a�o (0 para Lunes, 1 para Martes, etc.): ";
    std::cin >> primerDia;

    std::cout << "�El a�o es bisiesto? (1 para bisiesto, 0 para no bisiesto): ";
    std::cin >> esBisiesto;

    std::string diasSemana[7] = { "Lunes", "Martes", "Mi�rcoles", "Jueves", "Viernes", "S�bado", "Domingo" };
    std::string meses[12] = { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };

    int diasMes[12] = { 31, 28 + esBisiesto, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int dia = 1;

    for (int mes = 0; mes < 12; ++mes) {
        std::cout << "Calendario de " << meses[mes] << ":\n";
        std::cout << "------------------------\n";
        std::cout << "L   M   X   J   V   S   D\n";
        for (int i = 0; i < primerDia; ++i) {
            std::cout << "    ";
        }
        for (int i = 1; i <= diasMes[mes]; ++i) {
            if (i < 10) {
                std::cout << " ";
            }
            std::cout << i << "  ";
            if ((i + primerDia) % 7 == 0 || i == diasMes[mes]) {
                std::cout << "\n";
            }
        }
        std::cout << "\n";
        primerDia = (primerDia + diasMes[mes]) % 7;
    }

    return 0;
}